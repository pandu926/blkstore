<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'HomeController@index');
Route::get('/admin', 'AdminController@index');
Route::get('/admin/dashboard', 'AdminController@index');
Route::get('/admin/daftar', 'AdminController@daftar');
Route::post('/admin/daftar', 'AdminController@store');
Route::post('/admin/info', 'DatasController@store');
Route::get('/admin/info', 'DatasController@index');
Route::get('/admin/info/data/{$data}', 'DatasController@show');
Route::get('/anime/{slug}', 'HomeController@show');
Route::get('/tags', 'HomeController@tags');
route::get('/testes', 'AdminController@cek');
Route::get('/tags/{slug}','HomeController@tag');
route::get('/admin/edit/{slug}', 'AdminController@edit');

Auth::routes();






