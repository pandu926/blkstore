@extends('layouthome')

@section('content')
    <div id="loginform" class="container">
        <h1 class="text-light text-center mb-5">Silahkan Login </h1>
        <label for="name">nama</label>
        <input type="text">
    </div>
@endsection