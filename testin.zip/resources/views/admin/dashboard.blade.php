@extends('layoutadmin')

@section('konten')
    <h1>Selamat Datang Admin</h1>
@endsection